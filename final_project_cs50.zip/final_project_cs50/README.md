# Project Title

CRUDS

## Description

TO CALCULATE PRODUCTS WITH MULTIPLICATION

## Getting Started

### Dependencies

* You can put the product name first, and then put the product price. There are non-compulsory additions, which are as follows...

* 1- Taxes.
* 2- Advertisements.
* 3 - discount


### Installing

No need to install

### Executing program


TO CALCULATE PRODUCTS WITH MULTIPLICATION
```

## Help

If you would like to help, send a message to 050169445
```
```
## Authors

Contributors names and contact info

Mr. Fahd Abdulaziz  
ex. [@Fahd13A](https://twitter.com/Fahd13A)

## Version History

* 0.2
    * Various bug fixes and optimizations
    * See [commit change]() or See [release history]()
* 0.1
    * Initial Release

## License

This project is licensed under the [CS50] License - see the LICENSE.md file for details

## Acknowledgments

Inspiration, code snippets, etc.
* [awesome-readme](https://github.com/matiassingers/awesome-readme)
* [PurpleBooth](https://gist.github.com/PurpleBooth/109311bb0361f32d87a2)
* [dbader](https://github.com/dbader/readme-template)
* [zenorocha](https://gist.github.com/zenorocha/4526327)
* [fvcproductions](https://gist.github.com/fvcproductions/1bfc2d4aecb01a834b46)